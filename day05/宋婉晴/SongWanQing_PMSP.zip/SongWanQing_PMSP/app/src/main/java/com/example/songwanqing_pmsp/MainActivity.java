package com.example.songwanqing_pmsp;

import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.songwanqing_pmsp.adapter.RlvAdapter;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private TextView text;
    private TabLayout tab;
    private RelativeLayout rel;
    private RlvAdapter adapter;
    private RecyclerView rel2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        text = (TextView) findViewById(R.id.text);
        tab = (TabLayout) findViewById(R.id.tab);
        rel = (RelativeLayout) findViewById(R.id.rel);
        rel2 = (RecyclerView) findViewById(R.id.rel2);

        tab.addTab(tab.newTab().setText("首页").setIcon(R.drawable.icon_home_pager_selected));
        tab.addTab(tab.newTab().setText("写诗").setIcon(R.drawable.icon_knowledge_hierarchy_selected));
        tab.addTab(tab.newTab().setIcon(R.drawable.icon_pause));
        tab.addTab(tab.newTab().setText("作品").setIcon(R.drawable.icon_project_selected));
        tab.addTab(tab.newTab().setText("我的").setIcon(R.drawable.icon_me_selected));
        rel2.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RlvAdapter(this);
        rel2.setAdapter(adapter);


    }
}
