package com.example.songwanqing_pmsp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.songwanqing_pmsp.R;

public class RlvAdapter extends RecyclerView.Adapter {
    private Context context;

    public RlvAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 1) {
            View one = LayoutInflater.from(context).inflate(R.layout.layout_one, parent, false);
            return new OneHolder(one);
        }
        if (viewType == 2) {
            View four = LayoutInflater.from(context).inflate(R.layout.layout_four, parent, false);
            return new OneHolder(four);
        }
        if (viewType == 3) {
            View two = LayoutInflater.from(context).inflate(R.layout.layout_two, parent, false);
            return new TwoHolder(two);
        }
        View three = LayoutInflater.from(context).inflate(R.layout.layout_three, parent, false);
        return new ThreeHolder(three);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 4;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return 1;
        }
        if (position == 1) {
            return 2;
        }
        if (position == 2) {
            return 3;
        }
        return 4;

    }

    public static
    class OneHolder extends RecyclerView.ViewHolder {
        public View rootView;
        public ImageView one_img;

        public OneHolder(View rootView) {
            super(rootView);
            this.rootView = rootView;
            this.one_img = (ImageView) rootView.findViewById(R.id.one_img);
        }
    }

    public static
    class TwoHolder extends RecyclerView.ViewHolder {
        public View rootView;
        public ImageView two_img;

        public TwoHolder(View rootView) {
            super(rootView);
            this.rootView = rootView;
            this.two_img = (ImageView) rootView.findViewById(R.id.two_img);
        }
    }

    public static
    class ThreeHolder extends RecyclerView.ViewHolder {
        public View rootView;
        public TextView tv_text;

        public ThreeHolder(View rootView) {
            super(rootView);
            this.rootView = rootView;
            this.tv_text = (TextView) rootView.findViewById(R.id.tv_text);
        }

    }

    public static
    class FourHolder extends RecyclerView.ViewHolder{
        public View rootView;
        public LinearLayout rel;

        public FourHolder(View rootView) {
            super(rootView);
            this.rootView = rootView;
            this.rel = (LinearLayout) rootView.findViewById(R.id.rel);
        }

    }
}
